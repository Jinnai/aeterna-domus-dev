import {
  acknowledgeNarration,
  createCampaign,
  endActionPhase,
  pendingNarrations,
  processMonthlyUpdate,
  projectActionAvailability,
  promptProjection,
  spendActionPoint,
  validateCampaignState,
} from "./domain.mjs";

const PACKAGE_ID = "aeterna-domus";
const KIND = "campaign-state";
const documentId = (chatId) => `${PACKAGE_ID}:campaign:${chatId}`;
const now = () => new Date().toISOString();

async function readState(runtime, chatId) {
  const record = await runtime.persistence.documents.getById(PACKAGE_ID, documentId(chatId));
  return record ? { record, state: validateCampaignState(record.data) } : null;
}

async function createState(runtime, chatId, options = {}) {
  const existing = await readState(runtime, chatId);
  if (existing) return existing;
  const timestamp = now();
  const state = createCampaign({ ...options, campaignId: chatId });
  const record = await runtime.persistence.documents.create({
    id: documentId(chatId),
    packageId: PACKAGE_ID,
    kind: KIND,
    name: `${state.houseName} Campaign`,
    description: "Authoritative Aeterna Domus campaign state",
    data: state,
    createdAt: timestamp,
    updatedAt: timestamp,
  });
  return { record, state };
}

async function replaceState(runtime, existing, state) {
  const record = await runtime.persistence.documents.update({
    id: existing.record.id,
    packageId: PACKAGE_ID,
    expectedRevision: existing.record.revision,
    name: existing.record.name,
    description: existing.record.description,
    data: validateCampaignState(state),
    updatedAt: now(),
  });
  if (!record) throw new Error("Campaign state changed concurrently; reload and try again");
  return { record, state: record.data };
}

function chatIdFrom(request) {
  const value = request.params?.chatId;
  if (typeof value !== "string" || !value.trim()) throw new Error("chatId is required");
  return value.trim();
}

function responsePayload(stored, extra = {}) {
  return {
    revision: stored.record.revision,
    state: stored.state,
    availability: projectActionAvailability(stored.state),
    pendingNarrations: pendingNarrations(stored.state),
    ...extra,
  };
}

function setupOptions(chatMeta) {
  const config = chatMeta?.experienceConfig;
  return config && typeof config === "object" && !Array.isArray(config) ? config : {};
}

export async function activate(context) {
  const runtime = context.api.runtime;

  const releasePrompt = context.api.registerPromptContext(async ({ chatId, chatMeta, mode }) => {
    if (mode !== "game" || chatMeta?.gameExperienceId !== PACKAGE_ID) return null;

    const stored = await readState(runtime, chatId);
    // Game creation may request its opening generation before the client can
    // initialize package storage. Project the selected setup deterministically
    // for that first generation; the initialize route persists the same state.
    const state = stored?.state ?? createCampaign({
      ...setupOptions(chatMeta),
      campaignId: chatId,
    });

    return {
      text: promptProjection(state),
      provides: { inventory: true },
    };
  });

  const releaseRoutes = await context.api.registerPrivilegedRoutes(async (routes) => {
    routes.get("/campaign/:chatId", async (request, reply) => {
      const stored = await readState(runtime, chatIdFrom(request));
      if (!stored) return reply.status(404).send({ error: "Campaign has not been initialized" });
      return responsePayload(stored);
    });

    routes.post("/campaign/:chatId/initialize", async (request, reply) => {
      const body = request.body && typeof request.body === "object" ? request.body : {};
      const stored = await createState(runtime, chatIdFrom(request), { ...body, queueOpeningNarration: true });
      return reply.status(201).send(responsePayload(stored));
    });

    routes.post("/campaign/:chatId/action", async (request, reply) => {
      const chatId = chatIdFrom(request);
      return runtime.persistence.withChatLock(chatId, async () => {
        const stored = await readState(runtime, chatId);
        if (!stored) return reply.status(404).send({ error: "Campaign has not been initialized" });
        const body = request.body && typeof request.body === "object" ? request.body : {};
        const outcome = spendActionPoint(stored.state, body.action);
        if (!outcome.accepted) return reply.status(400).send({ error: outcome.error, state: stored.state });
        const saved = await replaceState(runtime, stored, outcome.state);
        return responsePayload(saved, { resolution: outcome.resolution });
      });
    });

    routes.post("/campaign/:chatId/end-actions", async (request, reply) => {
      const chatId = chatIdFrom(request);
      return runtime.persistence.withChatLock(chatId, async () => {
        const stored = await readState(runtime, chatId);
        if (!stored) return reply.status(404).send({ error: "Campaign has not been initialized" });
        const outcome = endActionPhase(stored.state);
        if (!outcome.accepted) return reply.status(400).send({ error: outcome.error, state: stored.state });
        const saved = await replaceState(runtime, stored, outcome.state);
        return responsePayload(saved);
      });
    });

    routes.post("/campaign/:chatId/narrations/:narrationId/acknowledge", async (request, reply) => {
      const chatId = chatIdFrom(request);
      return runtime.persistence.withChatLock(chatId, async () => {
        const stored = await readState(runtime, chatId);
        if (!stored) return reply.status(404).send({ error: "Campaign has not been initialized" });
        const narrationIdValue = String(request.params?.narrationId || "");
        const outcome = acknowledgeNarration(stored.state, narrationIdValue);
        if (!outcome.accepted) return reply.status(404).send({ error: outcome.error });
        const saved = await replaceState(runtime, stored, outcome.state);
        return responsePayload(saved);
      });
    });

    routes.post("/campaign/:chatId/next", async (request, reply) => {
      const chatId = chatIdFrom(request);
      return runtime.persistence.withChatLock(chatId, async () => {
        const stored = await readState(runtime, chatId);
        if (!stored) return reply.status(404).send({ error: "Campaign has not been initialized" });
        try {
          const saved = await replaceState(runtime, stored, processMonthlyUpdate(stored.state));
          return responsePayload(saved);
        } catch (error) {
          return reply.status(400).send({
            error: error instanceof Error ? error.message : "Month could not advance",
          });
        }
      });
    });
  }, { prefix: "/api/aeterna-domus" });

  runtime.logger.info("Aeterna Domus Stage 1 runtime activated");
  return async () => {
    releasePrompt();
    releaseRoutes();
  };
}

export async function selfCheck(context) {
  if (context.package.id !== PACKAGE_ID) throw new Error("Aeterna Domus package id mismatch");
  if (typeof context.api.runtime.persistence.documents.getById !== "function") {
    throw new Error("Package document storage is unavailable");
  }
}
