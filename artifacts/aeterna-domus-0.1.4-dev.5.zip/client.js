const TAG = "marinara-capability-aeterna-domus";
const API = "/api/aeterna-domus";

const escapeHtml = (value) => String(value ?? "").replace(/[<>&"']/g, (character) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
})[character]);
const titleCase = (value) => String(value || "").replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());

export function filterGmConnections(connections) {
  return (Array.isArray(connections) ? connections : [])
    .filter((entry) => entry && typeof entry.id === "string" && entry.id.trim()
      && entry.provider !== "image_generation" && entry.provider !== "video_generation")
    .map((entry) => ({
      id: entry.id,
      name: typeof entry.name === "string" && entry.name.trim() ? entry.name.trim() : "Unnamed connection",
      model: typeof entry.model === "string" ? entry.model.trim() : "",
      provider: typeof entry.provider === "string" ? entry.provider : "",
      isDefault: entry.isDefault === true || entry.isDefault === "true",
    }));
}

export function buildGameSetupConfig(config) {
  return {
    genre: "Historical tycoon, estate simulation, RPG",
    setting: "An alternate-antiquity Roman world without magic, centered on a rising noble House outside Rome; cultures and empires are distinctive without requiring strict historical accuracy.",
    tone: "Relaxing power fantasy, luxurious and character-driven, with grounded consequences for reckless choices and mistreatment.",
    difficulty: "Easy",
    combatStyle: "classic",
    gameWorldMapMode: "standard",
    rating: "nsfw",
    gmMode: "standalone",
    partyCharacterIds: [],
    playerGoals: "Build a dominant Roman House through estate development, personnel, production, trade, arena glory, politics, culture, and relationships.",
    enableCustomWidgets: false,
    enableSpriteGeneration: false,
    ...config,
  };
}

class AeternaDomusElement extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.state = null;
    this.availability = null;
    this.pendingNarrations = [];
    this.sendingNarrationId = null;
    this.loading = false;
    this.error = null;
    this.notice = null;
    this.selectedApSourceId = "general";
    this.gmConnections = null;
    this.gmConnectionsError = null;
    this.loadingGmConnections = false;
    this.setupDraft = null;
    this.reconcilingNarration = false;
    this.onProps = () => { this.render(); this.loadState(); this.loadGmConnections(); this.reconcilePendingNarrations(); };
  }

  connectedCallback() {
    this.addEventListener("marinara-capability-props", this.onProps);
    this.render();
    this.loadState();
    this.loadGmConnections();
  }
  disconnectedCallback() { this.removeEventListener("marinara-capability-props", this.onProps); }
  get props() { return this.capabilityProps || {}; }
  get view() { return this.getAttribute("view") || "surface"; }
  set view(value) {
    if (value == null) this.removeAttribute("view");
    else this.setAttribute("view", String(value));
  }

  async request(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      credentials: "same-origin",
      headers: { "content-type": "application/json", ...(options.headers || {}) },
      ...options,
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Request failed (${response.status})`);
    return payload;
  }

  captureSetupDraft() {
    const form = this.shadowRoot?.getElementById("setup");
    if (!form) return;
    const data = new FormData(form);
    this.setupDraft = Object.fromEntries(["gameName", "houseName", "founderName", "backgroundId", "foreignCulture", "gmConnectionId"]
      .map((key) => [key, data.get(key)]));
  }

  async loadGmConnections() {
    if (this.view !== "setup" || this.loadingGmConnections || this.gmConnections !== null) return;
    this.loadingGmConnections = true;
    try {
      const response = await fetch("/api/connections", { credentials: "same-origin" });
      const payload = await response.json().catch(() => []);
      if (!response.ok) throw new Error(payload?.error || `Connections could not be loaded (${response.status})`);
      this.captureSetupDraft();
      this.gmConnections = filterGmConnections(payload);
      this.gmConnectionsError = null;
      if (!this.setupDraft?.gmConnectionId) {
        const preferred = this.gmConnections.find((entry) => entry.isDefault) || this.gmConnections[0];
        if (preferred) this.setupDraft = { ...(this.setupDraft || {}), gmConnectionId: preferred.id };
      }
    } catch (error) {
      this.captureSetupDraft();
      this.gmConnections = [];
      this.gmConnectionsError = error instanceof Error ? error.message : "Connections could not be loaded";
    } finally {
      this.loadingGmConnections = false;
      this.render();
    }
  }

  acceptPayload(payload) {
    this.state = payload.state;
    this.availability = payload.availability || null;
    this.pendingNarrations = Array.isArray(payload.pendingNarrations) ? payload.pendingNarrations : [];
  }

  messageText(message) {
    const value = message?.content ?? message?.text ?? message?.mes;
    return typeof value === "string" ? value : "";
  }

  narrationMarker(transaction) { return `[AETERNA DOMUS TRANSACTION: ${transaction.id}]`; }

  narrationEvidence(transaction) {
    const messages = Array.isArray(this.props.messages) ? this.props.messages : [];
    const marker = this.narrationMarker(transaction);
    let requestIndex = -1;
    for (let index = 0; index < messages.length; index += 1) {
      const message = messages[index];
      const text = this.messageText(message);
      const legacyOpeningMatch = transaction.kind === "opening"
        && text.includes("[AETERNA DOMUS — OPENING NARRATION]")
        && text.includes(`House is exactly ${this.state?.houseName || ""}`);
      if ((message?.role === "user" || message?.role === "owner") && (text.includes(marker) || text.includes(transaction.ownerMessage) || legacyOpeningMatch)) {
        requestIndex = index;
      }
    }
    if (requestIndex < 0) return { requested: false, completed: false };
    const completed = messages.slice(requestIndex + 1).some((message) => message?.role === "assistant" || message?.role === "narrator");
    return { requested: true, completed };
  }

  async acknowledgeNarrationTransaction(transaction) {
    const payload = await this.request(`/campaign/${encodeURIComponent(this.props.chatId)}/narrations/${encodeURIComponent(transaction.id)}/acknowledge`, {
      method: "POST",
      body: "{}",
    });
    this.acceptPayload(payload);
    this.notice = `${transaction.title} narrated by the GM.`;
    this.error = null;
    return true;
  }

  async reconcilePendingNarrations() {
    if (this.reconcilingNarration || !this.props.chatId || this.pendingNarrations.length === 0) return false;
    const completed = this.pendingNarrations.find((transaction) => this.narrationEvidence(transaction).completed);
    if (!completed) return false;
    this.reconcilingNarration = true;
    try {
      await this.acknowledgeNarrationTransaction(completed);
      return true;
    } catch (error) {
      this.error = error instanceof Error ? error.message : "Completed GM narration could not be acknowledged";
      return false;
    } finally {
      this.reconcilingNarration = false;
      this.render();
    }
  }

  async dispatchNarration(transaction) {
    if (!transaction || this.sendingNarrationId || typeof this.props.sendMessage !== "function") return false;
    const evidence = this.narrationEvidence(transaction);
    if (evidence.completed) return this.reconcilePendingNarrations();
    if (evidence.requested || this.props.isStreaming) {
      this.notice = `GM narration is already in progress: ${transaction.title}`;
      this.render();
      return false;
    }
    this.sendingNarrationId = transaction.id;
    this.notice = `Requesting GM narration: ${transaction.title}`;
    this.render();
    try {
      const sent = await this.props.sendMessage(`${this.narrationMarker(transaction)}\n${transaction.ownerMessage}`);
      if (sent === false) throw new Error("The GM generation did not start");
      if (!this.pendingNarrations.some((entry) => entry.id === transaction.id)) return true;
      await this.acknowledgeNarrationTransaction(transaction);
      return true;
    } catch (error) {
      if (this.narrationEvidence(transaction).completed) return this.reconcilePendingNarrations();
      this.error = error instanceof Error ? error.message : "GM narration could not be requested";
      this.notice = `Mechanical state is saved. Narration ${transaction.id} remains pending; refresh after generation or retry if no GM turn appears.`;
      return false;
    } finally {
      this.sendingNarrationId = null;
      this.render();
    }
  }

  async dispatchFirstPending() {
    const transaction = this.pendingNarrations[0];
    return transaction ? this.dispatchNarration(transaction) : false;
  }

  async loadState() {
    if (this.view !== "surface" || this.props.layer === "underlay" || !this.props.chatId || this.loading) return;
    this.loading = true;
    try {
      this.acceptPayload(await this.request(`/campaign/${encodeURIComponent(this.props.chatId)}`));
      this.error = null;
      const opening = this.pendingNarrations.find((entry) => entry.kind === "opening");
      if (opening) {
        const reconciled = await this.reconcilePendingNarrations();
        const evidence = this.narrationEvidence(opening);
        if (!reconciled && !evidence.requested && !this.props.isStreaming) queueMicrotask(() => this.dispatchNarration(opening));
      }
    } catch (error) {
      this.error = error instanceof Error ? error.message : "Campaign state could not be loaded";
    } finally {
      this.loading = false;
      this.render();
    }
  }

  async mutate(path, body) {
    if (!this.props.chatId || this.loading) return;
    this.loading = true;
    try {
      const payload = await this.request(`/campaign/${encodeURIComponent(this.props.chatId)}${path}`, {
        method: "POST",
        body: JSON.stringify(body || {}),
      });
      this.acceptPayload(payload);
      this.notice = payload.resolution ? `${payload.resolution.title} — ${payload.resolution.summary}` : "Campaign state updated.";
      this.error = null;
      const pending = this.pendingNarrations[0] || null;
      if (pending) await this.dispatchNarration(pending);
    } catch (error) {
      this.error = error instanceof Error ? error.message : "Action could not be resolved";
      this.notice = null;
    } finally {
      this.loading = false;
      this.render();
    }
  }

  selectedSourceId() { return this.selectedApSourceId || "general"; }
  sourceFor(entry, sourceId = this.selectedSourceId()) { return entry?.sources?.find((source) => source.sourceId === sourceId); }
  actionWithSource(action) {
    const source = this.availability?.sources?.find((entry) => entry.id === this.selectedSourceId());
    return source?.kind === "delegated"
      ? { ...action, delegatedApId: source.id, actorId: source.actorId }
      : { ...action };
  }
  action(action) { return this.mutate("/action", { action: this.actionWithSource(action) }); }

  style() {
    return `<style>
      :host{display:block;box-sizing:border-box;min-height:0;height:100%;overflow:hidden;pointer-events:auto;color:var(--foreground,#f5ead2);font:13px/1.4 ui-sans-serif,system-ui}.panel{box-sizing:border-box;height:100%;min-height:0;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;pointer-events:auto;border:1px solid color-mix(in srgb,var(--border,#8b6f47) 70%,#c89b4b);border-radius:14px;background:color-mix(in srgb,var(--card,#211c18) 92%,transparent);padding:14px;box-shadow:0 12px 40px #0005}.stack{display:grid;gap:12px}.row{display:flex;gap:8px;align-items:center;justify-content:space-between}.stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px}.stat,.card{border-radius:9px;background:#0002;padding:9px}.label{font-size:10px;text-transform:uppercase;letter-spacing:.08em;opacity:.65}.value{font-size:16px;font-weight:700;color:#d8ad59}.columns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.cards{display:grid;gap:7px}.card-head{display:flex;justify-content:space-between;gap:8px}.muted{opacity:.68;font-size:11px}.error{color:#ff9e91}.notice{color:#b9e59b;border-left:3px solid #79a85d;padding-left:8px}h3,h4{margin:0;color:#e4bd72}input,select,button{box-sizing:border-box;width:100%;min-height:38px;border-radius:8px;border:1px solid var(--border,#715f48);background:var(--background,#17130f);color:inherit;padding:8px}button{cursor:pointer;background:#7a3e25;font-weight:700}button.secondary{background:transparent}button:disabled{cursor:not-allowed;opacity:.45}.tabs{display:flex;gap:6px;flex-wrap:wrap}.tabs button{width:auto;min-height:30px;padding:4px 9px}.actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.reason{color:#e8b29c;font-size:11px}.perk{color:#cbb5e9}.laurels{color:#e8c76a}@media(max-width:700px){.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.columns,.actions{grid-template-columns:1fr}}
    </style>`;
  }

  render() {
    if (!this.shadowRoot) return;
    if (this.view === "setup") return this.renderSetup();
    if (this.props.layer === "underlay") { this.shadowRoot.innerHTML = `${this.style()}<div aria-hidden="true"></div>`; return; }
    this.renderSurface();
  }

  renderSetup() {
    const cultures = ["Hellenic League", "Egyptian Kingdom", "Carthage", "Indian Ocean Kingdoms", "Celestial Empire", "Wilderlands"];
    const draft = this.setupDraft || {};
    const value = (key, fallback) => escapeHtml(draft[key] ?? fallback);
    const selected = (key, candidate, fallback) => String(draft[key] ?? fallback) === candidate ? "selected" : "";
    const connections = this.gmConnections || [];
    const connectionOptions = connections.map((entry) => {
      const details = [entry.model, entry.provider].filter(Boolean).join(" · ");
      const label = `${entry.name}${details ? ` — ${details}` : ""}${entry.isDefault ? " (Default)" : ""}`;
      return `<option value="${escapeHtml(entry.id)}" ${selected("gmConnectionId", entry.id, connections.find((item) => item.isDefault)?.id || connections[0]?.id || "")}>${escapeHtml(label)}</option>`;
    }).join("");
    const connectionStatus = this.loadingGmConnections || this.gmConnections === null
      ? "Loading saved text-generation Connections…"
      : this.gmConnectionsError
        ? `Could not load Connections: ${escapeHtml(this.gmConnectionsError)}`
        : connections.length === 0
          ? "No eligible text-generation Connection exists. Create one in Settings → Connections first."
          : "The selected saved Connection will narrate as the standalone GM.";
    this.shadowRoot.innerHTML = `${this.style()}<form class="panel stack" id="setup">
      <h3>Found Your House</h3>
      <label><span class="label">Game name</span><input name="gameName" value="${value("gameName", "Aeterna Domus")}" required></label>
      <label><span class="label">House name</span><input name="houseName" value="${value("houseName", "House Varro")}" required></label>
      <label><span class="label">Founder</span><input name="founderName" value="${value("founderName", "Marcus Varro")}" required></label>
      <label><span class="label">Background</span><select name="backgroundId"><option value="merchant_heir" ${selected("backgroundId", "merchant_heir", "merchant_heir")}>Merchant's Heir — production, specialist, Granary</option><option value="arena_patron" ${selected("backgroundId", "arena_patron", "merchant_heir")}>Arena Patron — training, gladiator, Ludus, Fame</option><option value="senatorial_favors" ${selected("backgroundId", "senatorial_favors", "merchant_heir")}>Senatorial Favors — politics, secretary, Banquet Hall</option><option value="foreign_heritage" ${selected("backgroundId", "foreign_heritage", "merchant_heir")}>Foreign Heritage — research, specialist, Scriptorium</option></select></label>
      <label><span class="label">Foreign culture</span><select name="foreignCulture">${cultures.map((culture) => `<option ${selected("foreignCulture", culture, cultures[0])}>${escapeHtml(culture)}</option>`).join("")}</select></label>
      <label><span class="label">GM Connection</span><select name="gmConnectionId" required ${connections.length === 0 ? "disabled" : ""}>${connectionOptions || `<option value="">No eligible Connection available</option>`}</select><span class="muted">${connectionStatus}</span></label>
      <p class="error" id="error"></p><div class="row"><button class="secondary" type="button" id="cancel">Cancel</button><button type="submit" ${connections.length === 0 ? "disabled" : ""}>Begin inheritance</button></div>
    </form>`;
    this.shadowRoot.getElementById("cancel")?.addEventListener("click", () => this.props.onCancel?.());
    this.shadowRoot.getElementById("setup")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = new FormData(event.currentTarget);
      const config = Object.fromEntries(["houseName", "founderName", "backgroundId", "foreignCulture", "gmConnectionId"].map((key) => [key, form.get(key)]));
      if (!this.gmConnections?.some((entry) => entry.id === config.gmConnectionId)) {
        const node = this.shadowRoot.getElementById("error");
        if (node) node.textContent = "Choose an eligible saved text-generation Connection.";
        return;
      }
      const setupConfig = buildGameSetupConfig(config);
      try {
        const chatId = await this.props.onLaunch(setupConfig, String(form.get("gameName")), {
          initialize: async (createdChatId) => this.request(`/campaign/${encodeURIComponent(createdChatId)}/initialize`, {
            method: "POST",
            body: JSON.stringify(config),
          }),
        }, { gmConnectionId: config.gmConnectionId });
      } catch (error) {
        const node = this.shadowRoot.getElementById("error"); if (node) node.textContent = error instanceof Error ? error.message : "Campaign could not be created";
      }
    });
  }

  actionCard(title, entry, action, extra = "") {
    const source = this.sourceFor(entry);
    const disabled = !source?.available || this.loading;
    return `<div class="card"><div class="card-head"><strong>${escapeHtml(title)}</strong>${extra}</div>${source?.reason ? `<div class="reason">${escapeHtml(source.reason)}</div>` : ""}<button data-action='${escapeHtml(JSON.stringify(action))}' ${disabled ? "disabled" : ""}>Resolve action</button></div>`;
  }

  renderSurface() {
    const state = this.state;
    if (!state) { this.shadowRoot.innerHTML = `${this.style()}<div class="panel">${this.error ? `<p class="error">${escapeHtml(this.error)}</p>` : "Loading House ledger…"}</div>`; return; }
    const actionPhase = state.phase === "action";
    const sources = this.availability?.sources || [{ id: "general", label: `General AP (${state.actionPoints.general} remaining)` }];
    if (!sources.some((source) => source.id === this.selectedApSourceId)) this.selectedApSourceId = "general";
    const sourceOptions = sources.map((source) => `<option value="${escapeHtml(source.id)}" ${source.id === this.selectedApSourceId ? "selected" : ""}>${escapeHtml(source.label)}</option>`).join("");
    const facilities = state.facilities.map((entry) => `<div class="card"><div class="card-head"><strong>${escapeHtml(entry.name)}</strong><span>Level ${entry.level}</span></div><span class="muted">Upkeep ${entry.upkeep} D/month</span></div>`).join("");
    const projects = state.projects.map((entry) => `<div class="card"><strong>${escapeHtml(entry.facility?.name || entry.type)}</strong><div class="muted">${entry.turnsRemaining} monthly update(s) remaining</div></div>`).join("") || `<div class="muted">No active projects.</div>`;
    const personnel = state.personnel.map((entry) => `<div class="card"><div class="card-head"><strong>${escapeHtml(entry.name)}</strong><span class="laurels">${"★".repeat(entry.laurels)}</span></div><div>${titleCase(entry.profession)} · Level ${entry.level} (${entry.xp || 0}/${entry.level * 100} XP)</div><div class="muted">${titleCase(entry.status)} · ${escapeHtml(entry.origin)} · Loyalty ${entry.loyalty} · Relationship ${entry.relationship} · ${entry.monthlyCost} D/month</div>${(entry.personalPerks || []).map((perk) => `<div class="perk">${escapeHtml(perk)}</div>`).join("")}</div>`).join("");
    const roster = state.opportunityRoster.map((offer) => {
      const entry = this.availability?.recruitment?.find((item) => item.id === offer.id);
      const source = this.sourceFor(entry);
      return `<div class="card"><div class="card-head"><strong>${escapeHtml(offer.name)}</strong><span class="laurels">${"★".repeat(offer.laurels)}</span></div><div>${titleCase(offer.profession)} · Level ${offer.level} · ${titleCase(offer.status)}</div><div class="muted">${escapeHtml(offer.origin)} · ${offer.price} D · ${offer.monthlyCost} D/month</div>${source?.reason ? `<div class="reason">${escapeHtml(source.reason)}</div>` : ""}${actionPhase ? `<button data-action='${escapeHtml(JSON.stringify({ type: "hire", offerId: offer.id }))}' ${source?.available ? "" : "disabled"}>Recruit</button>` : ""}</div>`;
    }).join("");
    const construction = (this.availability?.construction || []).map((entry) => this.actionCard(entry.label, entry, entry.action, `<span>${entry.cost} D</span>`)).join("");
    const training = (this.availability?.training || []).map((entry) => this.actionCard(`Train ${entry.label}`, entry, entry.action, `<span>${entry.cost} D</span>`)).join("");
    const arena = (this.availability?.arena || []).map((entry) => this.actionCard(`Book bout: ${entry.label}`, entry, entry.action)).join("");
    const administration = (this.availability?.administration || []).map((entry) => this.actionCard(entry.label, entry, entry.action)).join("");
    const social = this.availability?.social ? this.actionCard(this.availability.social.label, this.availability.social, this.availability.social.action, `<span>${this.availability.social.cost} D</span>`) : "";
    const recent = (state.actionHistory || []).filter((entry) => entry.turn === state.date.turn).slice(-5).reverse().map((entry) => `<div class="card"><strong>${escapeHtml(entry.resolution.title)}</strong><div class="muted">${escapeHtml(entry.resolution.summary)}</div></div>`).join("") || `<div class="muted">No actions resolved this month.</div>`;
    const latestReport = (state.monthlyReports || []).at(-1);
    const report = latestReport ? `<div class="card"><div class="card-head"><strong>Month ${latestReport.month}, Year ${latestReport.year}</strong><span>${latestReport.ledger.net >= 0 ? "+" : ""}${latestReport.ledger.net} D</span></div><div>Income ${latestReport.ledger.income} D · Expenses ${latestReport.ledger.expenses.total} D</div><div class="muted">Production: ${latestReport.ledger.production.grain} grain, ${latestReport.ledger.production.olives} olives · Morale ${latestReport.moraleBefore} → ${latestReport.moraleAfter}</div></div>` : `<div class="muted">The first monthly report will appear after Free-Roam ends.</div>`;
    const pendingNarration = this.pendingNarrations.map((entry) => `<div class="card"><strong>${escapeHtml(entry.title)}</strong><div class="muted">Mechanics are saved; GM narration is pending.</div><button class="secondary" data-retry-narration="${escapeHtml(entry.id)}" ${this.sendingNarrationId ? "disabled" : ""}>Retry GM narration</button></div>`).join("");

    this.shadowRoot.innerHTML = `${this.style()}<aside class="panel stack">
      <div class="row"><div><h3>${escapeHtml(state.houseName)}</h3><div class="muted">Month ${state.date.month}, Year ${state.date.year} · ${titleCase(state.phase)}</div></div><strong>${state.actionPoints.general} General AP</strong></div>
      <div class="stats"><div class="stat"><div class="label">Denarii</div><div class="value">${state.resources.denarii}</div></div><div class="stat"><div class="label">Net/month</div><div class="value">${state.ledger.net >= 0 ? "+" : ""}${state.ledger.net}</div></div><div class="stat"><div class="label">Fame</div><div class="value">${state.resources.fame}</div></div><div class="stat"><div class="label">Influence</div><div class="value">${state.resources.influence}</div></div><div class="stat"><div class="label">Morale</div><div class="value">${state.resources.estateMorale} / 100</div></div></div>
      ${this.notice ? `<div class="notice">${escapeHtml(this.notice)}</div>` : ""}${this.error ? `<div class="error">${escapeHtml(this.error)}</div>` : ""}${pendingNarration ? `<section class="stack"><h4>Pending GM Narration</h4>${pendingNarration}</section>` : ""}
      ${actionPhase ? `<section class="stack"><h4>Action Phase</h4><label><span class="label">AP source</span><select id="ap-source">${sourceOptions}</select></label><div class="actions">${construction}${training}${arena}${administration}${social}</div><button id="end-actions" class="secondary">End Action Phase</button></section>` : `<button id="next-month" ${state.phase !== "free_roam" ? "disabled" : ""}>End Free-Roam and begin next month</button>`}
      <div class="columns"><section class="stack"><h4>Estate</h4><div class="cards">${facilities}</div><h4>Projects</h4><div class="cards">${projects}</div><h4>Latest Monthly Report</h4><div class="cards">${report}</div></section><section class="stack"><h4>Monthly Opportunities</h4><div class="cards">${roster}</div><h4>Recent Resolutions</h4><div class="cards">${recent}</div></section></div>
      <section class="stack"><h4>Personnel</h4><div class="columns">${personnel}</div></section><button id="refresh" class="secondary">Refresh state</button>
    </aside>`;

    this.shadowRoot.getElementById("ap-source")?.addEventListener("change", (event) => {
      this.selectedApSourceId = event.currentTarget.value;
      this.render();
    });
    this.shadowRoot.querySelectorAll("[data-action]").forEach((button) => button.addEventListener("click", () => {
      try { this.action(JSON.parse(button.dataset.action)); } catch { this.error = "Action payload is invalid"; this.render(); }
    }));
    this.shadowRoot.getElementById("end-actions")?.addEventListener("click", () => this.mutate("/end-actions"));
    this.shadowRoot.getElementById("next-month")?.addEventListener("click", () => this.mutate("/next"));
    this.shadowRoot.querySelectorAll("[data-retry-narration]").forEach((button) => button.addEventListener("click", () => {
      const transaction = this.pendingNarrations.find((entry) => entry.id === button.dataset.retryNarration);
      if (transaction) this.dispatchNarration(transaction);
    }));
    this.shadowRoot.getElementById("refresh")?.addEventListener("click", () => this.loadState());
    this.props.setExperienceChrome?.({
      providesInventory: true,
      providesCombat: true,
      providesChoices: true,
      providesPlayerInput: state.phase !== "free_roam",
    });
  }
}

if (!customElements.get(TAG)) customElements.define(TAG, AeternaDomusElement);
