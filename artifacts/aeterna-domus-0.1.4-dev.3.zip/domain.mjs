export const PACKAGE_ID = "aeterna-domus";
export const STATE_VERSION = 1;
export const PHASES = Object.freeze({
  UPDATE: "update",
  OPPORTUNITIES: "opportunities",
  ACTION: "action",
  FREE_ROAM: "free_roam",
});

export const BACKGROUNDS = Object.freeze({
  merchant_heir: {
    id: "merchant_heir",
    name: "Merchant's Heir",
    passive: { basicGoodsProductionMultiplier: 1.25 },
    fame: 0,
    influence: 0,
    facility: { id: "granary", name: "Granary", level: 1, upkeep: 8 },
    person: {
      id: "starting-farm-specialist",
      name: "Aulus",
      profession: "farm_specialist",
      status: "enslaved",
      origin: "Rome",
      laurels: 2,
      level: 1,
      xp: 0,
      loyalty: 52,
      relationship: 0,
      monthlyCost: 7,
    },
  },
  arena_patron: {
    id: "arena_patron",
    name: "Arena Patron",
    passive: { trainingXpMultiplier: 1.2 },
    fame: 2,
    influence: 0,
    facility: { id: "ludus", name: "Ludus", level: 1, upkeep: 12 },
    person: {
      id: "starting-gladiator",
      name: "Caius",
      profession: "gladiator",
      status: "enslaved",
      origin: "Rome",
      laurels: 1,
      level: 1,
      xp: 0,
      loyalty: 45,
      relationship: 0,
      monthlyCost: 9,
    },
  },
  senatorial_favors: {
    id: "senatorial_favors",
    name: "Senatorial Favors",
    passive: { positivePoliticalEventWeightMultiplier: 1.05 },
    fame: 0,
    influence: 5,
    facility: { id: "banquet-hall", name: "Banquet Hall", level: 1, upkeep: 10 },
    person: {
      id: "starting-political-secretary",
      name: "Decimus",
      profession: "political_secretary",
      status: "free",
      origin: "Rome",
      laurels: 2,
      level: 1,
      xp: 0,
      loyalty: 58,
      relationship: 10,
      monthlyCost: 16,
    },
  },
  foreign_heritage: {
    id: "foreign_heritage",
    name: "Foreign Heritage",
    passive: { researchSpeedMultiplier: 1.15 },
    fame: 0,
    influence: 0,
    facility: { id: "scriptorium", name: "Scriptorium", level: 1, upkeep: 9 },
  },
});

export const PROTOTYPE_CULTURES = Object.freeze([
  "Hellenic League",
  "Egyptian Kingdom",
  "Carthage",
  "Indian Ocean Kingdoms",
  "Celestial Empire",
  "Wilderlands",
]);

const BASE_FACILITIES = Object.freeze([
  { id: "atrium", name: "Modest Atrium", level: 1, upkeep: 0 },
  { id: "servants-quarters", name: "Servants' Quarters", level: 1, upkeep: 8 },
  { id: "farmstead", name: "Farmstead and Fields", level: 1, upkeep: 12 },
  { id: "storehouse", name: "Small Storehouse", level: 1, upkeep: 4 },
  { id: "lararium", name: "Family Lararium", level: 1, upkeep: 0 },
]);

const BASE_PERSONNEL = Object.freeze([
  {
    id: "lucius-varro",
    name: "Lucius Varro",
    profession: "villa_steward",
    status: "free",
    origin: "Rome",
    laurels: 3,
    level: 3,
    xp: 0,
    loyalty: 68,
    relationship: 20,
    monthlyCost: 18,
    personalPerks: ["Orderly Accounts"],
  },
  {
    id: "tertia",
    name: "Tertia",
    profession: "domestic_servant",
    status: "enslaved",
    origin: "Italia",
    laurels: 2,
    level: 1,
    xp: 20,
    loyalty: 52,
    relationship: 5,
    monthlyCost: 6,
    personalPerks: ["Observant"],
  },
  {
    id: "felix",
    name: "Felix",
    profession: "domestic_servant",
    status: "enslaved",
    origin: "Italia",
    laurels: 1,
    level: 1,
    xp: 10,
    loyalty: 48,
    relationship: 0,
    monthlyCost: 6,
    personalPerks: ["Industrious"],
  },
]);

const OFFER_NAMES = Object.freeze([
  "Marcellus", "Vibia", "Nicanor", "Sabina", "Titus",
  "Damaris", "Gaius", "Livia", "Theron", "Cassia",
]);
const OFFER_PROFESSIONS = Object.freeze([
  "domestic_servant", "farm_specialist", "artisan", "gladiator", "scribe", "guard",
]);

export const FACILITY_CATALOG = Object.freeze({
  "granary:1": { id: "granary", name: "Granary", level: 1, cost: 190, upkeep: 8, buildTurns: 1 },
  "olive-press:1": { id: "olive-press", name: "Olive Press", level: 1, cost: 280, upkeep: 12, buildTurns: 1 },
  "workshop:1": { id: "workshop", name: "Workshop", level: 1, cost: 300, upkeep: 14, buildTurns: 1 },
  "ludus:1": { id: "ludus", name: "Ludus", level: 1, cost: 360, upkeep: 12, buildTurns: 1 },
  "banquet-hall:1": { id: "banquet-hall", name: "Banquet Hall", level: 1, cost: 300, upkeep: 10, buildTurns: 1 },
  "scriptorium:1": { id: "scriptorium", name: "Scriptorium", level: 1, cost: 300, upkeep: 9, buildTurns: 1 },
  "courtesan-quarters:1": { id: "courtesan-quarters", name: "Courtesan Quarters", level: 1, cost: 260, upkeep: 10, buildTurns: 1 },
});

export const ACTION_TYPES = Object.freeze({
  CONSTRUCT: "construct",
  HIRE: "hire",
  TRAIN: "train",
  BOOK_ARENA_BOUT: "book_arena_bout",
  OPTIMIZE_PRODUCTION: "optimize_production",
  HOST_SOCIAL_EVENT: "host_social_event",
});

export const ACTION_DEFINITIONS = Object.freeze({
  [ACTION_TYPES.CONSTRUCT]: { category: "administration", label: "Begin construction" },
  [ACTION_TYPES.HIRE]: { category: "administration", label: "Hire or acquire personnel" },
  [ACTION_TYPES.TRAIN]: { category: "training", label: "Train a gladiator" },
  [ACTION_TYPES.BOOK_ARENA_BOUT]: { category: "arena", label: "Book an arena bout" },
  [ACTION_TYPES.OPTIMIZE_PRODUCTION]: { category: "administration", label: "Optimize production" },
  [ACTION_TYPES.HOST_SOCIAL_EVENT]: { category: "social", label: "Host a social event" },
});

export function hashSeed(value) {
  let hash = 2166136261;
  for (const character of String(value)) {
    hash ^= character.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function mulberry32(seed) {
  let value = seed >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let mixed = value;
    mixed = Math.imul(mixed ^ (mixed >>> 15), mixed | 1);
    mixed ^= mixed + Math.imul(mixed ^ (mixed >>> 7), mixed | 61);
    return ((mixed ^ (mixed >>> 14)) >>> 0) / 4294967296;
  };
}

function copy(value) { return JSON.parse(JSON.stringify(value)); }
function integer(value, fallback = 0) { return Number.isInteger(value) ? value : fallback; }
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }

export function createCampaign(options = {}) {
  const background = BACKGROUNDS[options.backgroundId] ?? BACKGROUNDS.merchant_heir;
  const culture = PROTOTYPE_CULTURES.includes(options.foreignCulture)
    ? options.foreignCulture
    : PROTOTYPE_CULTURES[0];
  const facilities = [...copy(BASE_FACILITIES), copy(background.facility)];
  const personnel = [...copy(BASE_PERSONNEL)];

  if (background.person) personnel.push(copy(background.person));
  if (background.id === "foreign_heritage") {
    personnel.push({
      id: "starting-foreign-specialist",
      name: options.foreignSpecialistName?.trim() || "Alexios",
      profession: "foreign_specialist",
      status: "free",
      origin: culture,
      laurels: 3,
      level: 1,
      xp: 0,
      loyalty: 55,
      relationship: 5,
      monthlyCost: 18,
      personalPerks: [`${culture} Education`],
    });
  }

  const state = {
    schemaVersion: STATE_VERSION,
    campaignId: String(options.campaignId || "unbound"),
    seed: integer(options.seed, hashSeed(options.campaignId || Date.now())),
    houseName: options.houseName?.trim() || "House Varro",
    founderName: options.founderName?.trim() || "Marcus Varro",
    backgroundId: background.id,
    date: { month: 3, year: 1, turn: 1 },
    phase: PHASES.ACTION,
    resources: {
      denarii: 600,
      fame: background.fame,
      influence: background.influence,
      estateMorale: 55,
    },
    actionPoints: { general: 2, delegated: [] },
    facilities,
    personnel,
    workforce: [{
      id: "field-cohort",
      name: "Seasonal Field Cohort",
      count: 4,
      monthlyCost: 20,
    }],
    production: { grain: 15, olives: 12 },
    inventory: { grain: 0, olives: 0 },
    passives: copy(background.passive),
    ledger: null,
    opportunityRoster: [],
    projects: [],
    effects: [],
    flags: {},
    actionHistory: [],
    monthlyReports: [],
    narrationQueue: [],
    log: [],
  };

  state.opportunityRoster = generateOpportunityRoster(state);
  state.ledger = projectMonthlyLedger(state);
  return state;
}

export function projectMonthlyLedger(state) {
  const temporaryProductionMultiplier = (state.effects || []).reduce(
    (multiplier, effect) => multiplier * Number(effect.productionMultiplier || 1),
    1,
  );
  const productionMultiplier = Number(state.passives?.basicGoodsProductionMultiplier || 1) * temporaryProductionMultiplier;
  const grain = Math.floor(15 * productionMultiplier);
  const olives = Math.floor(12 * productionMultiplier);
  const grainSold = Math.max(0, grain - 4);
  const olivesSold = Math.max(0, olives - 1);
  const baseSales = grainSold * 8 + olivesSold * 7;
  const sales = Math.round(baseSales * 1.05);
  const personnel = state.personnel.reduce((sum, person) => sum + integer(person.monthlyCost), 0);
  const workforce = state.workforce.reduce((sum, cohort) => sum + integer(cohort.monthlyCost), 0);
  const buildings = state.facilities.reduce((sum, facility) => sum + integer(facility.upkeep), 0);
  const living = 18;
  const expenses = personnel + workforce + buildings + living;

  return {
    production: { grain, olives },
    sales,
    income: sales,
    expenses: { personnel, workforce, buildings, living, total: expenses },
    net: sales - expenses,
  };
}

function narrationId(state, kind) {
  const existing = Array.isArray(state.narrationQueue) ? state.narrationQueue.length : 0;
  return `${kind}-${state.date.turn}-${existing + 1}`;
}

function queueNarration(state, kind, title, ownerMessage, payload = {}) {
  state.narrationQueue = Array.isArray(state.narrationQueue) ? state.narrationQueue : [];
  const transaction = {
    id: narrationId(state, kind),
    kind,
    turn: state.date.turn,
    title,
    ownerMessage,
    payload: copy(payload),
    status: "pending",
  };
  state.narrationQueue.push(transaction);
  return transaction;
}

function actionPhaseEntries(state) {
  return (state.actionHistory || []).filter((entry) => entry.turn === state.date.turn);
}

function queueActionPhaseNarration(state) {
  const transactionKey = `action_phase:${state.date.turn}`;
  if ((state.narrationQueue || []).some((entry) => entry.payload?.transactionKey === transactionKey)) return null;
  const entries = actionPhaseEntries(state);
  const numbered = entries.length
    ? entries.map((entry, index) => `${index + 1}. ${entry.resolution.title}\n${entry.resolution.summary}`).join("\n")
    : "No major actions were taken; the House deliberately conserved its remaining opportunities.";
  return queueNarration(
    state,
    "action_phase",
    `Action Phase resolved — Month ${state.date.month}`,
    `[AETERNA DOMUS — NARRATE RESOLVED ACTION PHASE]\nThe package has already validated, applied, and persisted every mechanical result below. Narrate these outcomes in order. Do not recalculate costs, AP, rewards, XP, prerequisites, or state; do not add further mechanical effects. Keep this as concise management narration rather than interactive roleplay. After the results, clearly announce PHASE 3: FREE-ROAM PHASE and establish the estate scene.\n\n${numbered}`,
    { transactionKey, resolutions: entries.map((entry) => copy(entry.resolution)) },
  );
}

export function processMonthlyUpdate(state) {
  if (pendingNarrations(state).length > 0) {
    throw new Error("Pending GM narration must be sent before the month can advance");
  }
  if (state.phase !== PHASES.FREE_ROAM && state.phase !== PHASES.UPDATE) {
    throw new Error("A month can advance only from Free-Roam or Update Phase");
  }

  const next = copy(state);
  next.phase = PHASES.UPDATE;
  next.projects = Array.isArray(next.projects) ? next.projects : [];
  next.effects = Array.isArray(next.effects) ? next.effects : [];

  const completedProjects = [];
  for (const project of next.projects) {
    project.turnsRemaining -= 1;
    if (project.turnsRemaining <= 0 && project.type === "construction") {
      next.facilities.push(copy(project.facility));
      completedProjects.push(project);
    }
  }
  next.projects = next.projects.filter((project) => !completedProjects.includes(project));

  const treasuryBefore = next.resources.denarii;
  const moraleBefore = next.resources.estateMorale;
  const ledger = projectMonthlyLedger(next);
  next.ledger = ledger;
  next.production = ledger.production;
  next.resources.denarii += ledger.net;
  next.resources.estateMorale = clamp(next.resources.estateMorale + 1, 0, 100);
  next.effects = next.effects
    .map((effect) => ({ ...effect, turnsRemaining: effect.turnsRemaining - 1 }))
    .filter((effect) => effect.turnsRemaining > 0);
  next.date.turn += 1;
  next.date.month += 1;
  if (next.date.month > 12) {
    next.date.month = 1;
    next.date.year += 1;
  }
  next.actionPoints.general = 2;
  next.actionPoints.delegated = deriveDelegatedAp(next);
  next.opportunityRoster = generateOpportunityRoster(next);
  next.phase = PHASES.ACTION;
  const report = {
    id: `monthly-report-${next.date.turn}`,
    turn: next.date.turn,
    month: next.date.month,
    year: next.date.year,
    treasuryBefore,
    treasuryAfter: next.resources.denarii,
    moraleBefore,
    moraleAfter: next.resources.estateMorale,
    ledger: copy(ledger),
    completedProjects: completedProjects.map((project) => ({
      id: project.id,
      name: project.facility?.name || "Estate project",
      level: project.facility?.level || 1,
    })),
    opportunities: copy(next.opportunityRoster),
  };
  next.monthlyReports = Array.isArray(next.monthlyReports) ? next.monthlyReports : [];
  next.monthlyReports.push(report);
  const completedText = report.completedProjects.length
    ? report.completedProjects.map((project) => `${project.name} Level ${project.level}`).join(", ")
    : "None";
  const rosterText = report.opportunities.map((offer) =>
    `- ${offer.name}: ${offer.profession.replaceAll("_", " ")}, Level ${offer.level}, ${offer.laurels} Laurels, ${offer.status}, ${offer.price} D upfront, ${offer.monthlyCost} D/month`
  ).join("\n");
  queueNarration(
    next,
    "monthly_update",
    `Monthly Update — Month ${next.date.month}, Year ${next.date.year}`,
    `[AETERNA DOMUS — NARRATE AUTHORITATIVE MONTHLY UPDATE]\nPresent PHASE 1: UPDATE PHASE, followed by MONTHLY OPPORTUNITIES (Phase 1.5), then announce PHASE 2: ACTION PHASE. All numbers and offers below are already calculated and persisted. Do not change them or invent mechanical rewards, losses, unlocks, or events. You may add brief grounded world-news atmosphere and rumors only if they have no mechanical effect.\n\nTreasury: ${report.treasuryBefore} D → ${report.treasuryAfter} D (${ledger.net >= 0 ? "+" : ""}${ledger.net} D)\nIncome: ${ledger.income} D\nExpenses: ${ledger.expenses.total} D (personnel ${ledger.expenses.personnel}, workforce ${ledger.expenses.workforce}, buildings ${ledger.expenses.buildings}, living ${ledger.expenses.living})\nProduction: ${ledger.production.grain} grain, ${ledger.production.olives} olives\nEstate Morale: ${report.moraleBefore} → ${report.moraleAfter}\nCompleted projects: ${completedText}\nGeneral AP available: ${next.actionPoints.general}; delegated AP available: ${next.actionPoints.delegated.reduce((sum, ap) => sum + ap.remaining, 0)}\n\nRotating personnel roster (exact potential):\n${rosterText || "No offers this month"}`,
    { transactionKey: `monthly_update:${next.date.turn}`, reportId: report.id },
  );
  next.log.push({
    type: "monthly_update",
    turn: next.date.turn,
    ledger,
    reportId: report.id,
    completedProjects: completedProjects.map((project) => project.id),
  });
  return next;
}

export function deriveDelegatedAp(state) {
  const result = [];
  for (const person of state.personnel) {
    if (person.profession === "villa_steward" && person.level >= 5) {
      result.push({
        id: `${person.id}:administration`,
        actorId: person.id,
        actorName: person.name,
        category: "administration",
        remaining: 1,
      });
    }
    if (person.profession === "lanista" && person.level >= 10) {
      result.push({
        id: `${person.id}:training`,
        actorId: person.id,
        actorName: person.name,
        category: "training",
        remaining: 1,
      });
    }
  }
  return result;
}

export function validateAtomicAction(action) {
  if (!action || typeof action !== "object" || Array.isArray(action)) {
    return { ok: false, error: "Action must be one object" };
  }
  if (!ACTION_DEFINITIONS[action.type]) return { ok: false, error: "Action type is not supported" };
  if (Array.isArray(action.actions) || Array.isArray(action.objectives)) {
    return { ok: false, error: "One order cannot contain multiple actions" };
  }
  const text = typeof action.description === "string" ? action.description : "";
  if (/\b(and then|as well as|also arrange|then negotiate|and arrange)\b/i.test(text)) {
    return { ok: false, error: "Bundled objectives must be split into atomic actions" };
  }
  return { ok: true };
}

function facility(state, id, minimumLevel = 1) {
  return state.facilities.find((entry) => entry.id === id && entry.level >= minimumLevel);
}

function person(state, id) {
  return state.personnel.find((entry) => entry.id === id);
}

function gainXp(target, amount) {
  target.xp = integer(target.xp) + amount;
  const levels = [];
  while (target.level < 20 && target.xp >= target.level * 100) {
    target.xp -= target.level * 100;
    target.level += 1;
    levels.push(target.level);
  }
  return levels;
}

function reject(state, error) {
  return { state, accepted: false, error };
}

function applyTypedEffect(next, action) {
  if (action.type === ACTION_TYPES.CONSTRUCT) {
    const blueprint = FACILITY_CATALOG[`${action.facilityId}:${integer(action.level, 1)}`];
    if (!blueprint) return { error: "That facility tier is not available in this prototype" };
    if (facility(next, blueprint.id, blueprint.level)) return { error: `${blueprint.name} ${blueprint.level} is already built` };
    if (next.projects.some((project) => project.type === "construction" && project.facility.id === blueprint.id)) {
      return { error: `${blueprint.name} is already under construction` };
    }
    if (next.resources.denarii < blueprint.cost) return { error: `${blueprint.cost} D is required` };
    next.resources.denarii -= blueprint.cost;
    next.projects.push({
      id: `construction-${blueprint.id}-${next.date.turn}`,
      type: "construction",
      turnsRemaining: blueprint.buildTurns,
      facility: { id: blueprint.id, name: blueprint.name, level: blueprint.level, upkeep: blueprint.upkeep },
    });
    return {
      resolution: {
        type: action.type,
        title: `Construction begun: ${blueprint.name} ${blueprint.level}`,
        summary: `${blueprint.cost} D committed; completion expected in ${blueprint.buildTurns} monthly update.`,
        changes: { denarii: -blueprint.cost, projectId: `construction-${blueprint.id}-${next.date.turn}` },
      },
    };
  }

  if (action.type === ACTION_TYPES.HIRE) {
    const offerIndex = next.opportunityRoster.findIndex((offer) => offer.id === action.offerId);
    if (offerIndex < 0) return { error: "That personnel offer is not in this month's roster" };
    const offer = next.opportunityRoster[offerIndex];
    if (next.resources.denarii < offer.price) return { error: `${offer.price} D is required` };
    next.resources.denarii -= offer.price;
    next.opportunityRoster.splice(offerIndex, 1);
    next.personnel.push({
      ...copy(offer),
      xp: 0,
      loyalty: offer.status === "enslaved" ? 45 : 55,
      relationship: 0,
      personalPerks: copy(offer.personalPerks || []),
    });
    return {
      resolution: {
        type: action.type,
        title: `${offer.status === "free" ? "Retainer hired" : "Personnel acquired"}: ${offer.name}`,
        summary: `${offer.name}, a Level ${offer.level} ${offer.laurels}-Laurel ${offer.profession}, joins the House.`,
        changes: { denarii: -offer.price, personnelId: offer.id },
      },
    };
  }

  if (action.type === ACTION_TYPES.TRAIN) {
    const target = person(next, action.personnelId);
    if (!target) return { error: "Training target was not found" };
    if (target.profession !== "gladiator") return { error: "This prototype training action requires a gladiator" };
    if (!facility(next, "ludus")) return { error: "Ludus I is required for gladiator training" };
    const cost = 20;
    if (next.resources.denarii < cost) return { error: `${cost} D is required for training supplies` };
    const xp = Math.round(40 * Number(next.passives.trainingXpMultiplier || 1));
    next.resources.denarii -= cost;
    const levels = gainXp(target, xp);
    return {
      resolution: {
        type: action.type,
        title: `Training completed: ${target.name}`,
        summary: `${target.name} gains ${xp} XP${levels.length ? ` and reaches Level ${target.level}` : ""}.`,
        changes: { denarii: -cost, personnelId: target.id, xp, levels },
      },
    };
  }

  if (action.type === ACTION_TYPES.BOOK_ARENA_BOUT) {
    const target = person(next, action.personnelId);
    if (!target || target.profession !== "gladiator") return { error: "A House gladiator must be selected" };
    if (!facility(next, "ludus")) return { error: "Ludus I is required to arrange arena bookings" };
    if (next.resources.fame < 5) return { error: "Fame 5 is required for minor arena bookings" };
    const xp = 55;
    const purse = 85;
    const levels = gainXp(target, xp);
    next.resources.denarii += purse;
    next.resources.fame += 2;
    return {
      resolution: {
        type: action.type,
        title: `Minor arena bout resolved: ${target.name}`,
        summary: `${target.name} completes a favorable prototype booking, earning ${purse} D, ${xp} XP, and 2 Fame.`,
        changes: { denarii: purse, fame: 2, personnelId: target.id, xp, levels },
      },
    };
  }

  if (action.type === ACTION_TYPES.OPTIMIZE_PRODUCTION) {
    if (!action.actorId || !person(next, action.actorId)) return { error: "A House retainer must oversee optimization" };
    if (next.effects.some((effect) => effect.id === "production-optimization")) {
      return { error: "Production is already optimized for the next monthly update" };
    }
    next.effects.push({ id: "production-optimization", productionMultiplier: 1.1, turnsRemaining: 1 });
    return {
      resolution: {
        type: action.type,
        title: "Production workflows optimized",
        summary: "Basic-goods production receives +10% during the next monthly update.",
        changes: { effect: "production-optimization" },
      },
    };
  }

  if (action.type === ACTION_TYPES.HOST_SOCIAL_EVENT) {
    if (!facility(next, "banquet-hall")) return { error: "Banquet Hall I is required" };
    const cost = 60;
    if (next.resources.denarii < cost) return { error: `${cost} D is required to host the event` };
    next.resources.denarii -= cost;
    next.resources.fame += 2;
    next.resources.influence += 1;
    return {
      resolution: {
        type: action.type,
        title: "Private dinner hosted",
        summary: "The gathering costs 60 D and grants 2 Fame and 1 Influence.",
        changes: { denarii: -cost, fame: 2, influence: 1 },
      },
    };
  }

  return { error: "Action has no deterministic resolver" };
}

function consumeActionPoint(next, action) {
  const expectedCategory = ACTION_DEFINITIONS[action.type].category;
  const delegated = action.delegatedApId
    ? next.actionPoints.delegated.find((ap) => ap.id === action.delegatedApId)
    : null;
  if (action.delegatedApId && !delegated) return "That delegated AP does not exist";
  if (delegated) {
    if (delegated.remaining < 1 || delegated.category !== expectedCategory || action.actorId !== delegated.actorId) {
      return "That delegated AP cannot perform this action";
    }
    delegated.remaining -= 1;
    return null;
  }
  if (next.actionPoints.general < 1) return "No general AP remains";
  next.actionPoints.general -= 1;
  return null;
}

export function resolveAction(state, action) {
  const validation = validateAtomicAction(action);
  if (!validation.ok) return reject(state, validation.error);
  if (pendingNarrations(state).length > 0) return reject(state, "Pending GM narration must be sent before another major action");
  if (state.phase !== PHASES.ACTION) return reject(state, "Major actions are permitted only during Action Phase");

  const next = copy(state);
  const apError = consumeActionPoint(next, action);
  if (apError) return reject(state, apError);
  const effect = applyTypedEffect(next, action);
  if (effect.error) return reject(state, effect.error);

  next.actionHistory = Array.isArray(next.actionHistory) ? next.actionHistory : [];
  next.actionHistory.push({ turn: next.date.turn, action: copy(action), resolution: copy(effect.resolution) });
  next.log.push({ type: "action", turn: next.date.turn, action: copy(action), resolution: copy(effect.resolution) });
  const delegatedRemaining = next.actionPoints.delegated.reduce((sum, ap) => sum + ap.remaining, 0);
  if (next.actionPoints.general === 0 && delegatedRemaining === 0) {
    next.phase = PHASES.FREE_ROAM;
    queueActionPhaseNarration(next);
  }
  return { state: next, accepted: true, resolution: effect.resolution };
}

export function spendActionPoint(state, action) {
  return resolveAction(state, action);
}

export function endActionPhase(state) {
  if (pendingNarrations(state).length > 0) return reject(state, "Pending GM narration must be sent before Action Phase can end");
  if (state.phase !== PHASES.ACTION) return reject(state, "Only Action Phase can be ended");
  const next = copy(state);
  next.phase = PHASES.FREE_ROAM;
  const narration = queueActionPhaseNarration(next);
  next.log.push({ type: "action_phase_ended", turn: next.date.turn, narrationId: narration?.id || null });
  return { state: next, accepted: true, narration };
}

function availabilityForSources(state, action, sources) {
  return sources.map((source) => {
    const projectedAction = source.kind === "delegated"
      ? { ...action, delegatedApId: source.id, actorId: source.actorId }
      : { ...action };
    const outcome = resolveAction(state, projectedAction);
    return {
      sourceId: source.id,
      available: outcome.accepted,
      reason: outcome.accepted ? null : outcome.error,
    };
  });
}

export function projectActionAvailability(state) {
  const sources = [
    { id: "general", kind: "general", label: `General AP (${state.actionPoints.general} remaining)`, remaining: state.actionPoints.general },
    ...state.actionPoints.delegated.map((ap) => ({
      id: ap.id,
      kind: "delegated",
      label: `${ap.actorName}: ${ap.category} AP (${ap.remaining} remaining)`,
      actorId: ap.actorId,
      category: ap.category,
      remaining: ap.remaining,
    })),
  ];
  const withAvailability = (id, label, action, details = {}) => ({
    id,
    label,
    action,
    ...details,
    sources: availabilityForSources(state, action, sources),
  });

  return {
    phase: state.phase,
    sources,
    construction: Object.values(FACILITY_CATALOG).map((blueprint) => withAvailability(
      `${blueprint.id}:${blueprint.level}`,
      `${blueprint.name} ${blueprint.level}`,
      { type: ACTION_TYPES.CONSTRUCT, facilityId: blueprint.id, level: blueprint.level },
      { cost: blueprint.cost, turns: blueprint.buildTurns },
    )),
    recruitment: state.opportunityRoster.map((offer) => withAvailability(
      offer.id,
      offer.name,
      { type: ACTION_TYPES.HIRE, offerId: offer.id },
      { cost: offer.price },
    )),
    training: state.personnel
      .filter((entry) => entry.profession === "gladiator")
      .map((entry) => withAvailability(
        entry.id,
        entry.name,
        { type: ACTION_TYPES.TRAIN, personnelId: entry.id },
        { cost: 20 },
      )),
    arena: state.personnel
      .filter((entry) => entry.profession === "gladiator")
      .map((entry) => withAvailability(
        entry.id,
        entry.name,
        { type: ACTION_TYPES.BOOK_ARENA_BOUT, personnelId: entry.id },
      )),
    administration: state.personnel
      .filter((entry) => entry.profession === "villa_steward")
      .map((entry) => withAvailability(
        entry.id,
        `Optimize production with ${entry.name}`,
        { type: ACTION_TYPES.OPTIMIZE_PRODUCTION, actorId: entry.id },
      )),
    social: withAvailability(
      "private-dinner",
      "Host private dinner",
      { type: ACTION_TYPES.HOST_SOCIAL_EVENT },
      { cost: 60 },
    ),
  };
}

export function generateOpportunityRoster(state) {
  const random = mulberry32(hashSeed(`${state.seed}:${state.date.turn}:roster`));
  const count = 3 + Math.floor(random() * 4);
  const roster = [];

  for (let index = 0; index < count; index += 1) {
    const laurelsRoll = random();
    const laurels = laurelsRoll < 0.62 ? 1 : laurelsRoll < 0.9 ? 2 : 3;
    const profession = OFFER_PROFESSIONS[Math.floor(random() * OFFER_PROFESSIONS.length)];
    const status = random() < 0.55 ? "free" : "enslaved";
    const level = random() < 0.82 ? 1 : 2;
    const base = status === "free" ? 45 : 75;
    const price = Math.round(base * (1 + (laurels - 1) * 0.55) * (1 + (level - 1) * 0.35));
    const monthlyCost = status === "free"
      ? Math.round(8 + laurels * 4 + level * 3)
      : Math.round(4 + level * 2);

    roster.push({
      id: `offer-${state.date.turn}-${index}`,
      name: OFFER_NAMES[Math.floor(random() * OFFER_NAMES.length)],
      profession,
      status,
      origin: "Rome",
      laurels,
      level,
      xp: 0,
      price,
      monthlyCost,
      personalPerks: laurels >= 3 ? [`Gifted ${profession.replaceAll("_", " ")}`] : [],
    });
  }

  return roster;
}

export function pendingNarrations(state) {
  return (state.narrationQueue || []).filter((entry) => entry.status === "pending").map((entry) => copy(entry));
}

export function acknowledgeNarration(state, narrationIdValue) {
  const index = (state.narrationQueue || []).findIndex((entry) => entry.id === narrationIdValue && entry.status === "pending");
  if (index < 0) return reject(state, "Pending narration transaction was not found");
  const next = copy(state);
  next.narrationQueue[index].status = "sent";
  next.narrationQueue[index].sentAtTurn = next.date.turn;
  next.log.push({ type: "narration_sent", turn: next.date.turn, narrationId: narrationIdValue });
  return { state: next, accepted: true };
}

export function validateCampaignState(value) {
  if (!value || typeof value !== "object") throw new Error("Campaign state is missing");
  if (value.schemaVersion !== STATE_VERSION) {
    throw new Error(`Unsupported campaign schema ${value.schemaVersion}`);
  }
  if (!Object.values(PHASES).includes(value.phase)) throw new Error("Campaign phase is invalid");
  if (!value.resources || !Number.isInteger(value.resources.denarii)) {
    throw new Error("Campaign treasury is invalid");
  }
  if (!Array.isArray(value.personnel) || !Array.isArray(value.facilities)) {
    throw new Error("Campaign collections are invalid");
  }
  return value;
}

export function promptProjection(state) {
  const roster = state.opportunityRoster
    .map((offer) => `${offer.name} — ${offer.profession}, L${offer.level}, ${offer.laurels} Laurels, ${offer.price} D`)
    .join("\n");
  const delegatedAp = state.actionPoints.delegated.reduce((sum, ap) => sum + ap.remaining, 0);
  const recentResolutions = (state.actionHistory || [])
    .filter((entry) => entry.turn === state.date.turn)
    .slice(-4)
    .map((entry) => `- ${entry.resolution.title}: ${entry.resolution.summary}`)
    .join("\n");

  return `[AETERNA DOMUS — AUTHORITATIVE PACKAGE STATE]
House: ${state.houseName}; Founder: ${state.founderName}
Date: Month ${state.date.month}, Year ${state.date.year}; Phase: ${state.phase}
Denarii: ${state.resources.denarii}; Fame: ${state.resources.fame}; Influence: ${state.resources.influence}; Estate Morale: ${state.resources.estateMorale}
General AP: ${state.actionPoints.general}; Delegated AP: ${delegatedAp}
Projected monthly net: ${state.ledger?.net ?? 0} D
Monthly roster (exact potential):
${roster || "No offers"}
Mechanical resolutions this turn:
${recentResolutions || "None"}
Pending narration transactions: ${pendingNarrations(state).map((entry) => entry.id).join(", ") || "None"}
The package is authoritative. Do not invent, recalculate, or silently alter mechanical state. Action Phase orders must be atomic and receive no free-form roleplay. Free-Roam permits dialogue and only minor bounded relationship or loyalty effects; no major actions.`;
}
